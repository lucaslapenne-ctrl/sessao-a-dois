// Service worker do Sessão a Dois
// Ao mudar arquivos do app, troque a versão para forçar a atualização no celular.
const VERSAO = 'sessao-v1';
const ARQUIVOS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSAO).then((c) => c.addAll(ARQUIVOS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((chaves) =>
      Promise.all(chaves.filter((k) => k !== VERSAO).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);

  // Supabase, TMDB, login do Google etc. passam direto, sem cache.
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;

  // Páginas: tenta a rede primeiro (sempre a versão mais nova) e cai no cache se estiver offline.
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then((res) => {
          const copia = res.clone();
          caches.open(VERSAO).then((c) => c.put(req, copia));
          return res;
        })
        .catch(() => caches.match(req).then((r) => r || caches.match('./index.html')))
    );
    return;
  }

  // Demais arquivos do próprio site: cache primeiro, atualizando em segundo plano.
  e.respondWith(
    caches.match(req).then((cache) => {
      const rede = fetch(req)
        .then((res) => {
          if (res.ok) caches.open(VERSAO).then((c) => c.put(req, res.clone()));
          return res;
        })
        .catch(() => cache);
      return cache || rede;
    })
  );
});
